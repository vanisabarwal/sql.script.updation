package xpressbees.sql.model;

import javax.sql.DataSource;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.mysql.cj.jdbc.MysqlDataSource;

import org.postgresql.ds.PGSimpleDataSource;
import org.springframework.stereotype.Repository;

@Repository
public class MyDataSourceFactory
{
	public static DataSource getMySQLDataSource(databaseDetails dbcon)
	{
		MysqlDataSource mysqlDS = null;
		try {
			mysqlDS = new MysqlDataSource();
			mysqlDS.setURL("jdbc:mysql://"+ dbcon.getHostName()+ ":" + dbcon.getDbPort() + "/" + dbcon.getDbName());
			mysqlDS.setUser(dbcon.getUserName());
			mysqlDS.setPassword(dbcon.getDbPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mysqlDS;
	}
	
	
	public static DataSource getPostgreSQLDataSource(databaseDetails dbcon)
	{
	    PGSimpleDataSource psqlDS = null;
		try {
			
			psqlDS = new PGSimpleDataSource();
			psqlDS.setURL("jdbc:postgresql://"+ dbcon.getHostName()+ ":" + dbcon.getDbPort() + "/" + dbcon.getDbName());
			psqlDS.setUser(dbcon.getUserName());
			psqlDS.setPassword(dbcon.getDbPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return psqlDS;
	}
		
		public static DataSource getSQLServerDataSource(databaseDetails dbcon)
		{
			SQLServerDataSource mssqlDS = null;
			try {
				
				mssqlDS = new SQLServerDataSource();
				mssqlDS.setURL("jdbc:sqlserver://"+ dbcon.getHostName()+ ":" + dbcon.getDbPort() + ";encrypt=true;" + dbcon.getDbName());
				mssqlDS.setUser(dbcon.getUserName());
				mssqlDS.setPassword(dbcon.getDbPassword());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return mssqlDS;
		}
	
}

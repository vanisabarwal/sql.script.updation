package xpressbees.sql.dao;

import java.sql.Connection;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import xpressbees.sql.model.Client;
import xpressbees.sql.model.databaseDetails;

public interface UserDao 
{
	public int saveUser(Client client);
	
	public Client loginClient(String code, String password);
	
	public Connection testDataSource(databaseDetails dbcon, CommonsMultipartFile file);

	}

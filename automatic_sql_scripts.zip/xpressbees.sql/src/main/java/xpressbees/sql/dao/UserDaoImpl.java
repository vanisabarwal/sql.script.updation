package xpressbees.sql.dao;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.ibatis.jdbc.ScriptRunner;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import xpressbees.sql.model.Client;
import xpressbees.sql.model.MyDataSourceFactory;
import xpressbees.sql.model.databaseDetails;


@Repository
@Transactional
public class UserDaoImpl implements UserDao
{
	
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	

	@Override
	public int saveUser(Client client) {
		int id = (Integer) hibernateTemplate.save(client);
		return id;
	}

	
	@Override
	public Client loginClient(String code,String password) 
	{
		
		String sql = "FROM Client WHERE code=: cd and password=:pwd";
		Client c = (Client) hibernateTemplate.execute(s-> {
			Query q = s.createQuery(sql);
			q.setString("cd", code);
			q.setString("pwd", password);
			return q.uniqueResult();
		});
		return c;
	}
	

	@Override
	public Connection testDataSource(databaseDetails dbcon, CommonsMultipartFile file)
	{
		
		Connection con = null;
		DataSource ds = null;
		if("MySQL".equals(dbcon.getDbType()))
		{
			ds = MyDataSourceFactory.getMySQLDataSource(dbcon);
		}
		else if("PostgreSQL".equals(dbcon.getDbType()))
		{
			ds = MyDataSourceFactory.getPostgreSQLDataSource(dbcon);
		}
		else if("MS SQL".equals(dbcon.getDbType()))
		{
			ds = MyDataSourceFactory.getSQLServerDataSource(dbcon);
		}
		
		try
		{
			con = ds.getConnection();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				if(con != null)
				{
					System.out.println("Connected to Database Successfully");
				}
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		 String creationTime = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
 		 File sql = new File("D:\\sql_scripts_" + creationTime + ".sql");
 		try
 		{
 			PrintStream stream = new PrintStream(sql);
 		    System.setOut(stream);
 			Reader reader1 = new InputStreamReader(file.getInputStream());
 			CSVReader csvReader = new CSVReaderBuilder(reader1).withSkipLines(1).build();
 			List<String[]> allData = csvReader.readAll();
 			for (String[] row : allData)
 			{
 				System.out.println("COMMENT ON COLUMN " + row[0]+"."+ row[1] + " IS " + "'" +  row[2] + "';");
 				System.out.println();
 			}
 			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
 			ScriptRunner sr = new ScriptRunner(con);
 	 	     Reader reader = new BufferedReader(new FileReader(sql));
 	 	     sr.runScript(reader);
 	 	     System.out.println("Scripts executed Successfully");
 		}
 		catch(Exception e){
 			e.printStackTrace();
 		}
 		if(con != null)
 		{
 			try {
				con.close();
				System.out.println("Database Connection Closed");
			} 
 			catch (SQLException e) 
 			{
	
				e.printStackTrace();
			} 		
 		}
 		return con;
	}
}

package xpressbees.sql.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import xpressbees.sql.dao.UserDao;
import xpressbees.sql.model.Client;
import xpressbees.sql.model.databaseDetails;


@Controller
public class registerController
{   
	
	
	@Autowired
	private UserDao userDao;
	@RequestMapping("/")
	public String showForm()
	{
		return "register";
	}
    @RequestMapping(path = "/login", method = RequestMethod.POST)
    public String handleForm(@ModelAttribute Client client, Model model)
    {
    	System.out.println(client);
    	
    	userDao.saveUser(client);
    	return "login";
    }
   
    @RequestMapping(path = "/clientprofile", method = RequestMethod.POST)
    public String login(@RequestParam("code") String cd,
    		@RequestParam("password") String pwd, HttpSession session,Model model, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
    	
    	Client client =userDao.loginClient(cd,pwd);
    	if(client != null)
    	{
    		session.setAttribute("loginClient", client); 
    		return "profile";
    	}
    	else
    	{
    		response.setContentType("text/html");
    		PrintWriter pw=response.getWriter();
    		pw.println("<script type=\"text/javascript\">");
    		pw.println("alert('Invalid Username or Password');");
    		pw.println("</script>");
    		RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
    		rd.include(request, response);
    		return "login";
    	}
    	
    }
    
    @RequestMapping(path = "/logout", method = RequestMethod.GET )
	public String logout(HttpServletRequest request, Client client, Model model)
	{
	    HttpSession session = request.getSession();
		
	    session.removeAttribute("loginClient");
		model.addAttribute("msg", "Logout Successfully");
		
		return "register";
	}
    
    
    @RequestMapping(path = "/runscripts", method = RequestMethod.POST)
    public String uploadCSVFile(@RequestParam("CSVFile") CommonsMultipartFile file, @ModelAttribute databaseDetails dbcon, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
    	System.out.println("File Uploaded");
    	Connection conn = userDao.testDataSource(dbcon, file);
    	
    	if ( conn == null)
    	{
			response.setContentType("text/html");
    		PrintWriter pw=response.getWriter();
    		pw.println("<script type=\"text/javascript\">");
    		pw.println("alert('Invalid Database Credentials Entered!');");
    		pw.println("</script>");
    		RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
    		rd.include(request, response);
    		return "profile";
    	}
    	else
    	{
            return "success";
    	}
    }

}


